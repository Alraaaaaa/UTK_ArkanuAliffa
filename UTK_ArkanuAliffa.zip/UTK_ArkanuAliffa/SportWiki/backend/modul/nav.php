<nav class="navbar navbar-expand-bg bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="#"> </a>
      </li>
      <li class="nav-item">
        <a href="?page=AddArtikel" class="nav-link active" href="#"> </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>

    </ul>
  </div>
</nav>