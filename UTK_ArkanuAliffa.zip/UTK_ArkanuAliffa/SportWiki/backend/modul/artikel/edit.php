<?php
include'../lib/conn.php';
?>
<div class="m-4">
      <h2 class="m-4">Edit Artikel</h2>
<form action="" method="POST" enctype="multipart/form-data">
<div class="m-3">
  <label for="exampleFormControlInput1" class="form-label">Judul</label>
  <input type="text" class="form-control" name="judul">
</div>
<div class="m-3">
  <label for="exampleFormControlTextarea1" class="form-label">Konten</label>
  <textarea class="form-control"  rows="3" name="konten"></textarea>
</div>
<div class="m-3">
    <button type="submit" class="btn btn-primary" name="submit">Input Data</button>
</div>
</form>
<?php
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "SELECT * FROM artikel WHERE id_artikel = '$id'";
  $hasil = mysqli_query($conn, $query);
  if ($hasil && mysqli_num_rows($hasil) > 0) {
    $data = mysqli_fetch_assoc($hasil);
    $judul = $data['judul'];
    $konten = $data['konten'];
  }else {
    echo "Data tidak ada";
    exit();
  }
}

if (isset($_POST['submit'])) {
  $judul = $_POST['judul'];
  $konten = $_POST['konten'];
  $update = "UPDATE artikel SET judul='$judul', konten='$konten' WHERE id_artikel='$id'";
  $result = mysqli_query($conn, $update);
  if ($result) {
    echo "Data berhasil diupdate";
    exit();
  }else {
    echo "Gagal diupdate: " . mysqli_error($conn);
  }
}
?>
