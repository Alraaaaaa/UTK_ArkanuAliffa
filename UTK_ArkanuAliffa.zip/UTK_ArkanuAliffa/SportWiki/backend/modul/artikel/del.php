<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM artikel WHERE id_artikel = '$id'";
    $hasil = mysqli_query($conn, $query);

    if ($hasil) {
        echo "Data berhasil di hapus";
    }else {
        echo "Gagal menghapus data:" . mysqli_error($conn);
    }
}else {
    echo $query;
}
?>
