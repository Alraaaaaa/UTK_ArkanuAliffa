<?php
session_start();
$_SESSION = [];
session_destroy();
echo "Session destroyed. Redirecting";
header("Refresh: 2; URL=login.php");
exit();
?>