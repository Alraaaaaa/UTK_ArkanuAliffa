<?php
if (isset($_GET['idkat'])) {
  $id = $_GET['idkat'];
  $query = "SELECT * FROM kate WHERE id_kategori = '$id'";
  $hasil = mysqli_query($conn, $query);
 
    $data = mysqli_fetch_assoc($hasil);
    $judul = $data['nama_kategori'];
    $desk = $data['deskripsi_kategori'];
  
}

?>
<div class="m-4">
      <h2 class="m-4">Edit Kategori</h2>
<form action="" method="POST" enctype="multipart/form-data">
<div class="m-3">
  <label for="exampleFormControlInput1" class="form-label">Kategori</label>
  <input type="text" class="form-control" value="<?=$judul?>" name="judul">
</div>
<div class="m-3">
  <label for="exampleFormControlTextarea1" class="form-label">Deskripsi</label>
  <textarea class="form-control"  rows="3" name="desk"><?=$desk?></textarea>
</div>
<div class="m-3">
    <button type="submit" class="btn btn-primary" name="submit">Input Data</button>
</div>
</form>
<?php

if (isset($_POST['submit'])) {
  $judul = $_POST['judul'];
  $desk = $_POST['desk'];
  $update = "UPDATE kate SET nama_kategori='$judul', deskripsi_kategori='$desk' WHERE id_kategori='$id'";
  $result = mysqli_query($conn, $update);
  if ($result) {
    echo "Data berhasil diupdate";
    exit();
  }else {
    echo "Gagal diupdate: " . mysqli_error($conn);
  }
}
?>


ubur ubur ikan lele makan lele leee