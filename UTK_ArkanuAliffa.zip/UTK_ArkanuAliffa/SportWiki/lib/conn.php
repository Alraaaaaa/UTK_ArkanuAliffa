<?php
$host = 'localhost';
$db = 'db_utk';
$user = 'root';
$pass = '';

$conn = mysqli_connect($host, $user, $pass, $db);
if($conn){
    //echo'berhasil';
}else{
    echo'gagal';
}

?>
