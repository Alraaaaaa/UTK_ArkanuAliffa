<?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM kate WHERE id_kategori = '$id'";
    $hasil = mysqli_query($conn, $query);

    if ($hasil) {
        echo "Data berhasil di hapus";
    }else {
        echo "Gagal menghapus data:" . mysqli_error($conn);
    }
}else {
    echo $query;
}
?>
