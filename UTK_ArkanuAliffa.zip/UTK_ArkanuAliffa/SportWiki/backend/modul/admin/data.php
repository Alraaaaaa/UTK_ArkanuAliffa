<?php

?>
<div class="mt-4">
      <h2 class="mb-4">Kelola Artikel</h2>

      <!-- Table -->
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Konten</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php

              $no = 1;
              $sqlOut = mysqli_query($conn,"SELECT id_artikel, judul, konten FROM artikel");
          
              while ($row = $sqlOut->fetch_assoc()) {
              ?>
              <tr>
              <td><?=$no++?></td>
              <td><?=$row['judul']?></td>
              <td><?=$row['konten']?></td>
              <td>
                <a href="?page=edit&id=<?= $row['id_artikel']?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>

                <a href="?page=delete&id=<?= $row['id_artikel']?>" onclick="return confirm('Jangan nyesel ya')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
              </td>
            </tr>
              <?php
              }
//               $link = '../artikel/del.php?id=' . $row['id_artikel'];
// echo '<a href="' . $link . '">Hapus</a>';
// echo '<br>Debug Link:' . $link;
          ?>


          </tbody>
        </table>
      </div>
    </div>