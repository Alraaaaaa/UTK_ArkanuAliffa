<!DOCTYPE html>
<html lang="en">
<head>
  <title>UTK Arkan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body style="background-color: #222831;">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="../index.php"><-- Back</a>
      </li>

    </ul>
  </div>
</nav>
<?php
session_start();
include'../lib/conn.php';

if (isset($_POST['login'])) {
    $user = $_POST["username"];
    $pass = $_POST["password"];
    $stmt = $conn->prepare ("SELECT * FROM tb_user WHERE username = ? ");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows === 1){
      $user = $result->fetch_assoc();
      if (password_verify($pass, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        header("location: dashboard.php");
        exit();
      }else {
        echo "<script>alert('Password Salah'); window.location='login.php';</script>";
      }
    }else {
      $hashedPass = password_hash($pass, PASSWORD_DEFAULT);
      $insert = $conn->prepare("INSERT INTO tb_user(username, password) VALUES (?, ?)");
      $insert->bind_param("ss", $user, $hashedPass);
      if($insert->execute()){
        $_SESSION['username'] = $user;
        echo"<script>alert('Akun baru dibuat'); window.location='index.php'<;/script>";
      }else {
        echo"<script>alert('Gagal membuat akun'); window.location='login.php';</script>";
      }
    }

  } 
?>

<div class="container mt-3">
  <h2 class="text-light">Login To Upload A Article</h2>
  <form action="login.php" method="POST">
    <div class="mb-3 mt-3">
      <label for="text" class="text-light">Username:</label>
      <input type="text" class="form-control" id="" placeholder="Enter Username" name="username">
    </div>
    <div class="mb-3">
      <label for="password" class="text-light">Password:</label>
      <input type="password" class="form-control" id="" placeholder="Enter password" name="password">
    </div>
    <button type="submit" class="btn btn-success" name="login">Submit</button>
  </form>

</div>
</body>
</html>