<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
  <div class="sidebar">
    <h4 class="text-light ml-3">Dashboard Admin</h4>
    <a href="?page=admin"><i class="fas fa-images m-3"></i>Data Kategori</a>
    <a href="?page=AddArtikel"><i class="fas fa-images m-3"></i>Tambah Artikel</a>
    <a href="?page=kategori"><i class="fas fa-images m-3"></i>Kategori</a>
  </div>
  </div>
    <a href="/SportWiki/index.php" class="btn btn-primary m-3 d-flex">Home</a>
    <a href="?page=logout" class="btn btn-primary m-3 d-flex" >LogOut</a>
  
</nav>