<?php
include"../lib/conn.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTK Arkan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body{
            <--font-family: times-new-romans;-->
        }
        @font-face {
            font-family: 'MyCustomFont';
            src: url(aset/fonts/myfont.woff) format('woff');
            font-weight: normal;
            font-style: normal;
        }
        h2{
            font-family: 'MyCustomFont', sans-serif;
        }
    </style>
</head>
<body>
<?php
//include"modul/nav.php";
include"modul/sidebar.php";
?>

<?php
$page = isset($_GET['page']) ? $_GET['page'] : '';
switch ($page) {

    case "AddArtikel":
        include"modul/artikel/add.php";
        break;
    case 'kategori':
        include'modul/kategori/datakategori.php';
        break;
    case 'addkate':
        include'modul/kategori/addkate.php';
        break;
    case 'admin':
        include'modul/admin/data.php';
        break;
    case 'delete':
        include'modul/artikel/del.php';
        break;
    case 'del':
        include'modul/kategori/delete.php';
        break;
    case 'edit':
        include'modul/artikel/edit.php';
        break;
    case 'home':
        include'../index.php';
        break;
        case 'editkate':
            include'modul/kategori/editkate.php';
        break;
    case 'logout':
        header("Location: logout.php");
        exit();
        break;
        default:
        //echo "<style></style>";
        break;
?>
<?php
}
?>
<h2 style="color: #F7374F;">Wellcome,  <?php echo $_SESSION['username'];?></h2>
</body>
</html>