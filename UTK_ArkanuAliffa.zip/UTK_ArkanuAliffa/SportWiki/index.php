<?php
include"lib/conn.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTK Arkan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="">
    <style>
        body{
            background-color: #222831;
        }
    </style>
</head>
<body>
<?php
include"modul/navbar.php";
?>

<img src="/UTK_ArkanuAliffa/SportWiki/aset/img/bannerUtk.png" alt="" width="1361" height="200">

<?php
include'modul/sidebar.php';
?>

<?php
$hal = isset($_GET['hal']) ? $_GET['hal'] : '';
switch ($hal) {
        case 'home':
            include"index.php";
            break;

    
    default:
        //echo"Tidak Di Temukan";
        break;
}
?>
<div class="container py-5">
    <h3 class="mb-4 text-center text-light">Daftar Artikel</h3>
        
                <?php
                $artikel = $conn->query("SELECT * FROM artikel");
                if ($artikel->num_rows > 0) {
                    echo '<table class="table table-dark table-striped table-bordered">';
                    echo '<tr><th>Judul</th><th>Konten</th></tr>';
                    while ($row = $artikel->fetch_assoc()) {
                        echo "<tr><td>" . $row["judul"] . "</td><td>" . $row["konten"] . "</td></tr>";
                }
                    echo '</table>';
                ?>
        
        <?php
                }
                ?>
</div>
<script>
    fetch('http://localhost:3000/data')
    .then(res => res.json())
    .then(data => {
        const list = document.getElementById('artikel-list');
        data.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item.judul + " _ " + item.konten;
            list.appenChild(li);
        });
    });
    .catch(err => console.error('Fetch error:', err));
</script>
<footer class="text-center text-light"><b>Dibuat oleh Alra</b></footer>
</body>
</html>
