<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>UTK Arkan</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body style="background-color: #222831;">

<div class="container mt-3">
  <h2 class="text-light">Sign Up To Create An Account</h2>
  <form action="signup.php" method="POST">
    <div class="mb-3 mt-3">
      <label for="text" class="text-light">Username:</label>
      <input type="text" class="form-control" id="" placeholder="Enter Username" name="username">
    </div>
    <div class="mb-3">
      <label for="password" class="text-light">Password:</label>
      <input type="password" class="form-control" id="" placeholder="Enter password" name="password">
    </div>
    <input type="submit" class="btn btn-primary" name="signup">Submit</input>
  </form>
</div>
<?php
include'../lib/conn.php';
echo "<pre>";
print_r($_POST);
echo "</pre>";
if (isset($_POST['signup'])) {
    $user = $_POST['username'];
    $pass = password_hash($_POST[password], PASSWORD_DEFAULT);

    $cek = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$user'");
    if (mysqli_num_rows($cek) > 0) {
        echo "Username sudah dipakai";
    }else{
        $insert = mysqli_query($conn, "INSERT INTO tb_user(username, password) VALUES ('$user, $pass')");
        if ($insert) {
            echo "Berhasil, yay...";
            header("Location: dashboard.php");
            exit();
        }else{
            echo "Gagal, ugh...";
        }
    }
}
?>
</body>
</html>