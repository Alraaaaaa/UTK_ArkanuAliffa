<?php
include"../lib/conn.php";
?>
<div class="m-4">
      <h2 class="m-4">Tambah Data Kategori</h2>
<form action="" method="POST" enctype="multipart/form-data">
<div class="m-3">
  <label for="judulKate" class="form-label">Judul Kategori</label>
  <input type="text" class="form-control" name="judul">
</div>
<div class="m-3">
  <label for="deskripsiKate" class="form-label">Deskripsi</label>
  <textarea class="form-control"  rows="3" name="desk"></textarea>
</div>
<div class="m-3">
    <button type="submit" class="btn btn-success" name="btn">Input Data</button>
    </div>
</form>
<?php
  if(isset($_POST['btn'])){
    $judul = $_POST['judul'];
    $desk =$_POST['desk'];
    $sqlInp = $conn->prepare('INSERT INTO kate(nama_kategori, deskripsi_kategori)VALUES(?,?)');
    $sqlInp->bind_param("ss",$judul,$desk);
    if($sqlInp->execute()){
      echo"Berhasil";
    }else {
      echo "Gagal menambahkan data: " . $sqlInp->error;
  }
  }
?>


