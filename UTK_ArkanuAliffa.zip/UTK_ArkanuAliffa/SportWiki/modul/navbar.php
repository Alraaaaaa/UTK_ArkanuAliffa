<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href=""></a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="/SportWiki/backend/login.php">Upload</a>
      </li>
    </ul>
  </div>
</nav>