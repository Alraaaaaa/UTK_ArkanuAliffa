const express = require('express');
const app = express();
const port = 3000;
const cors = require('cors');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const db = mysql.createConnection({
	host: 'localhost';
	user: 'root';
	password: '';
	database: 'db_utk';
});

db.connect(err => {
	if (err) throw err;
	console.log('konek ke database');
})



let dataArtikel = [];

app.post('/input', (req, res) => {
	const { input } = req.body;
	dataArtikel.push(input);
	res.json({ message: 'Artikel Ditambahkan', data: dataArtikel });
})
app.get('/data', (req, res) => {
	db.query('SELECT * FROM artikel', (err, result) => {
		if (err) throw err;
		res.json(result) 
	})
});
app.listen(port, () => {
	console.log('Server jalan di http://localhost:${port}');
});